package com.YangYang;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ArrayList<Post> posts = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("=============양보드=============");

		xxx: while (true) {
			System.out.println("선택하슝:[1:글쓰기 , 2:글리스트, 3:글 읽기, 4:글삭제, 5:글수정 ,6:글 소개 이벤트 , e:종료]");
			String cmd = sc.next();
			switch (cmd) {
			case "1":// 글쓰기
				System.out.println("글제목은 모양??");
				String title = sc.next();
				System.out.println("당신 id는??");
				String id = sc.next();
				System.out.println("글내용?? 길게적기 금지ㅋㅋ");
				String content = sc.next();
				System.out.println("글번호 입력하세용~");
				int no = sc.nextInt();
				posts.add(new Post(title, id, content, no));
				break;
			case "2":// 글리스트
				for (int i = 0; i < posts.size(); i++) {
					System.out.print("글번호:" + posts.get(i).no);
					System.out.print(" ");
					System.out.print("글제목:" + posts.get(i).title);
					System.out.print(" ");
					System.out.print("작성자 id:" + posts.get(i).id);
					System.out.print(" ");
					System.out.print("글내용:" + posts.get(i).content);
					System.out.println(" ");
				}
				break;
			case "3": // 글읽기
				System.out.println("몇번 글 읽구시펑?????");
				int readNo = sc.nextInt();
				for (int i = 0; i < posts.size(); i++) {
					if (posts.get(i).no == readNo) {
						System.out.println("****************");
						System.out.println("글제목:" + posts.get(i).title);
						System.out.println("******************");
						System.out.println("작성자 id:" + posts.get(i).id);
						System.out.println("*****************");
						System.out.println("글내용:" + posts.get(i).content);
					}
				}
				break;
			case "4": // 글삭제
				System.out.println("몇번째 글 삭게하게");
				int delNo = sc.nextInt();
				for (int i = 0; i < posts.size(); i++) {
					if (posts.get(i).no == delNo) {
						System.out.println(posts.get(i).no + "번째 글을 삭제하였습니다.");
						posts.remove(i);
					}

				}
				break;
			case "5": // 글수정
				System.out.println("========글수정 페이지========");
				System.out.println("수정하실 글 번호를 입력해주세요. ");
				int edit_no = sc.nextInt();
				Post p = posts.get(edit_no);
				System.out.println("바꿀 제목?");
				p.title = sc.next();
				System.out.println("바꿀 내용?");
				p.content = sc.next();
				
				break;
				
				
			case "6": // 글 소개 이벤트
				System.out.println("참가하실 분은 참가 라고 입력하세요");
				String attend = sc.next();
				int r = (int) (Math.random() * posts.size());
				if (attend.equals("참가")) {
					System.out.println("축하합니다" + posts.get(r).no + "번 글이 당첨되었습니다");
					System.out.println("****************");
					System.out.println("글제목:" + posts.get(r).title);
					System.out.println("******************");
					System.out.println("작성자 id:" + posts.get(r).id);
					System.out.println("*****************");
					System.out.println("글내용:" + posts.get(r).content);
				}
				break;
			case "e": // 종료
				System.out.println("------------빠빠루우우우웅~~~~----------");
				break xxx;
			}
		}
	}
}