package com.YangYang;

public class Post {

	public String title;
	public String content;
	public String id;
	public int no;
	
	public Post(String title,String content,String id,int no) {
	
		this.title = title;
		this.content = content;
		this.id = id;
		this.no = no;
		
	}

}
